package com.example.boycott

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
